# AI Coding Session Logs

The hackathon requires `/logs` to contain the **full transcript of every
AI coding session** used to build this project. These must be your actual
exported/pasted conversations, not summaries or reconstructions.

## Where each transcript goes

| File | What should go in it |
|---|---|
| `session-01-design.md` | The conversation where the stack (Node + `node:sqlite`, no framework), architecture, and invariant strategy were decided. If this was one continuous session that also produced code, it's fine for it to overlap with `session-02`. |
| `session-02-naive.md` | The session where the naive (intentionally racy) implementation in `src/naive-server.js` was written and the race condition explained. |
| `session-03-load-test.md` | The session where `load-test/load-test.js` (the concurrency client + invariant verifier) was built. |
| `session-04-fix.md` | The session where the naive implementation was replaced with the corrected `src/server.js`, including the discussion of *why* the SQLite transaction approach is actually atomic. |
| `session-05-testing.md` | The session covering `tests/corrected.test.js`, the benchmark script, and the datastore-failure experiment. |
| `session-06-final-review.md` | Final cleanup, README/DECISIONS.md writing, and the final repository checklist pass. |

## How to export a transcript

Paste each full session — including your own prompts, not just the AI's
responses — into the matching file above, in plain Markdown or as raw
text. Do not trim "boring" parts (failed attempts, back-and-forth
debugging); that's exactly the record evaluators are asking for.

## What is currently in this directory

Only this README. The actual session transcripts have not been added yet
— they need to come from your real conversation history, not be
reconstructed after the fact. Export/paste them into the files named
above before submitting.
